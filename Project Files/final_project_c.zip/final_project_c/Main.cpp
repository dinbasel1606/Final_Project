#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Encoder2.h"
#include "Decoder2.h"
#include "Encoder3.h"
#include "Encoder4.h"
#include <time.h>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <vector>
#include <algorithm>
#include <bitset>
#include <cmath>

using namespace std;

int countDifferentBits(const int* array1, const int* array2, int size) {
    int count = 0;
    for (int i = 0; i < size; ++i) {
        int difference = array1[i] ^ array2[i]; // XOR to find differences
        // Count the set bits (bits that are different)
        while (difference != 0) {
            count += difference & 1;
            difference >>= 1;
        }
    }
    return count;
}

    int main() {
        double channelerrorpresent[120];// determine the error persentage in the channel.
        int flagofwhatprogram =1;//choosing 0 is forcing your desighned program and 1 is taking sattelite program
        int input[100];
        int rates[120];
        int errorbitsrate2[120];
        int errorbitsrate3[120];
        int errorbitsrate4[120];
        std::vector<int> index2;
        std::vector<int> index3;
        std::vector<int> index4;
        int i;
        int* decodedPath;
        int bitserror; // counting the number of error bits per run
        int numberofrate2=0;
        int numberofrate3=0;
        int numberofrate4=0;
        clock_t start_clock, end_clock;
        double elapsed_time;

        // Record the start time
        start_clock = clock();

        int ratesnew0[120]; // Array to store rates- rate will be either 2/3/4 matching to 1/2,1/3,1/4 rate 
       // Initialize the array
        for (int i = 0; i < 120; ++i) {
            if (i < 40) {
                ratesnew0[i] =3;
            }
            else if (i < 80) {
                ratesnew0[i] =3;
            }
            else {
                ratesnew0[i] = 3;
            }
        }
        
        
        int ratesnew1[120]; // Array to store rates- rate will be either 2/3/4 matching to 1/2,1/3,1/4 rate 
        // Read rates from the file
        ifstream infile("C:\\Users\\asuli\\OneDrive\\����� ������\\final_project_c\\encoder_rates.txt");
        if (!infile) {
            cerr << "Error: Unable to open input file." << endl;
            return 1;
        }
        for (int i = 0; i < 120; ++i) {
            if (!(infile >> ratesnew1[i])) {
                cerr << "Error: Unable to read rate " << i + 1 << " from the file." << endl;
                return 1;
            }
        }
        infile.close();

        // making the error presentage array
        for (int i = 0; i < 120; ++i) {
            if (ratesnew1[i] == 2) {
                channelerrorpresent[i] = 0.01;
            }
            if (ratesnew1[i] == 3) {
                channelerrorpresent[i] = 0.03;
            }
            if (ratesnew1[i] == 4) {
                channelerrorpresent[i] = 0.04;
            }

        }
        //choosing which program to take
        if (flagofwhatprogram == 0)
        {
            for (int i = 0; i < 120; ++i) {
                rates[i] = ratesnew0[i];
            }
        }
        else {
            for (int i = 0; i < 120; ++i) {
                rates[i] = ratesnew1[i];
            }
        }
        

        // Seed the random number generator
        srand(time(NULL));
        int inputSize = sizeof(input) / sizeof(input[0]);
        int outputSize;
        int* output;

        // Run the code multiple times
        for (int run = 0; run < 120; ++run) {
            // Initialize the array with random zeros and ones
            for (int i = 0; i < 98; i++) {
                input[i] = rand() % 2; // Generate a random number either 0 or 1
            }
            for (int i = 98; i < 100; i++) {
                input[i] = 0; // Generate K-1 zeros
            }
            // print the packet number
            printf("packet number: ");
            printf("%d \n", run);
            // print the rate
            printf("rate: ");
            printf("1/%d \n", rates[run]);
            // Print the input
            cout << "Input: ";
            for (int i = 0; i < 100; i++) {
                cout << input[i] << " ";
            }
            cout << endl;

            // Call the appropriate encoder function based on the rate
            if (rates[run] == 2) {
                index2.resize(rates[run]*100* channelerrorpresent[run]);
                // Initialize the array with random numbers
                for (int i = 0; i < rates[run] * 100 * channelerrorpresent[run]; i++) {
                    index2[i] = rand() % 200;
                }
                // Encode the message
                output=convolutionalEncoder(input, inputSize,&outputSize);
                //adding channelerrorpresent% of error
                if (channelerrorpresent != 0) {
                    for (int i = 0; i < rates[run] * 100 * channelerrorpresent[run]; i++) {
                        output[index2[i]] = !output[index2[i]];
                    }
                }
                // Print the output
                cout << "Encoded data with errors: ";
                for (int i = 0; i < outputSize; i++) {
                    cout << output[i] << " ";
                }
                cout << endl;
               // decode the data
               decodedPath = viterbiDecoder(output, outputSize);  // Decode the received data
                // Print the decoded path
               if (decodedPath != NULL) {
                    printf("Decoded data: ");
                    for (i = 0; i < outputSize / rates[run]; i++) {
                        printf("%d ", decodedPath[i]);
                    }
                    printf("\n");
                }
               bitserror = countDifferentBits(decodedPath, input, inputSize);
               printf("number of error bits: %d\n\n", bitserror);
               errorbitsrate2[run] = bitserror;
               errorbitsrate3[run] = -1; // flag
               errorbitsrate4[run] = -1;//flag
               numberofrate2 += 1;
            }
            else if (rates[run] == 3) {
                index3.resize(rates[run] * 100 * channelerrorpresent[run]);
                // Initialize the array with random numbers
                for (int i = 0; i < rates[run] * 100 * channelerrorpresent[run]; i++) {
                    index3[i] = rand() % 300;
                }
                //encode the message
                output = convolutionalEncoder3(input, inputSize, &outputSize);
                //adding channelerrorpresent% of error
                if (channelerrorpresent != 0) {
                    for (int i = 0; i < rates[run] * 100 * channelerrorpresent[run]; i++) {
                        output[index3[i]] = !output[index3[i]];
                    }
                }
                // Print the output
                cout << "Encoded data with errors: ";
                for (int i = 0; i < outputSize; i++) {
                    cout << output[i] << " ";
                }
                cout << endl;
                // decode the data
                decodedPath = viterbiDecoder3(output, outputSize);  // Decode the received data
                // Print the decoded path
                if (decodedPath != NULL) {
                    printf("Decoded data: ");
                    for (i = 0; i < outputSize / rates[run]; i++) {
                        printf("%d ", decodedPath[i]);
                    }
                    printf("\n");
                }
                bitserror = countDifferentBits(decodedPath, input, inputSize);
                printf("number of error bits: %d\n\n", bitserror);
                errorbitsrate3[run] = bitserror;
                errorbitsrate2[run] = -1; // flag
                errorbitsrate4[run] = -1;//flag
                numberofrate3 += 1;
            }
            else {
                index4.resize(rates[run] * 100 * channelerrorpresent[run]);
                // Initialize the array with random numbers
                for (int i = 0; i < rates[run] * 100 * channelerrorpresent[run]; i++) {
                    index4[i] = rand() % 400;
                }
                // encode the message
                output = convolutionalEncoder4(input, inputSize, &outputSize);
                //adding channelerrorpresent% of error
                if (channelerrorpresent != 0) {
                    for (int i = 0; i < rates[run] * 100 * channelerrorpresent[run]; i++) {
                        output[index4[i]] = !output[index4[i]];
                    }
                }
                // Print the output
                cout << "Encoded data with errors: ";
                for (int i = 0; i < outputSize; i++) {
                    cout << output[i] << " ";
                }
                cout << endl;
                // decode the data
                decodedPath = viterbiDecoder4(output, outputSize);  // Decode the received data
                // Print the decoded path
                if (decodedPath != NULL) {
                    printf("Decoded data: ");
                    for (i = 0; i < outputSize / rates[run]; i++) {
                        printf("%d ", decodedPath[i]);
                    }
                    printf("\n");
                }
                bitserror = countDifferentBits(decodedPath, input, inputSize);
                printf("number of error bits: %d\n\n", bitserror);
                errorbitsrate4[run] = bitserror;
                errorbitsrate2[run] = -1; // flag
                errorbitsrate3[run] = -1;//flag
                numberofrate4 += 1;
            }
            // Free the memory allocated for output
            delete[] output;
        }
        //printing the mean of the error bits in rate 1/2
        int finalerrors = 0;
        int count = 0;
        for (i = 0; i < 120; i++) {
            if (errorbitsrate2[i] != -1) {
                count += errorbitsrate2[i];
            }
        }
        finalerrors += count;
        printf("number of times rate 1/2 was done: %d\n", numberofrate2);
        printf("mean of error bits in rate 1/2: ");
        printf("%f\n", (static_cast<double>(count) / numberofrate2));
        //printing the mean of the error bits in rate 1/3
        count = 0;

        for (i = 0; i < 120; i++) {
            if (errorbitsrate3[i] != -1) {
                count += errorbitsrate3[i];
            }
        }
        finalerrors += count;
        printf("number of times rate 1/3 was done: %d\n", numberofrate3);
        printf("mean of error bits in rate 1/3: ");
        printf("%f\n", (static_cast<double>(count) / numberofrate3));
        //printing the mean of the error bits in rate 1/4
        count = 0;
        for (i = 0; i < 120; i++) {
            if (errorbitsrate4[i] != -1) {
                count += errorbitsrate4[i];
            }
        }
        finalerrors += count;
        printf("number of times rate 1/4 was done: %d\n", numberofrate4);
        printf("mean of error bits in rate 1/4: ");
        printf("%f\n\n", (static_cast<double>(count) / numberofrate4));
        printf("number of bit errors in the whole program: %d\n", finalerrors);
        printf("number of encoded bits that were sent in the channel in the whole program: %d\n", (numberofrate2*200 + numberofrate3 * 300 + numberofrate4 * 400));

        // Record the end time
        end_clock = clock();
        // Calculate the elapsed time in seconds
        elapsed_time = ((double)(end_clock - start_clock)) / CLOCKS_PER_SEC;
        // Print the elapsed time
        printf("Elapsed time: %.6f seconds\n", elapsed_time);

        return 0;
    }



