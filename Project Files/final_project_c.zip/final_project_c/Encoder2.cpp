﻿
#include <stdio.h>
#include <stdlib.h>

#define K 3

    // Convolutional Encoder Parameters
    const int numOutputs = 2;  // Number of output bits per input bit

    // Convolutional Encoder
    int* convolutionalEncoder(const int* input, int inputSize, int* outputSize) {
        int lastnum;
        int registers[K-1] = { 0 };  // Initialize registers to all zeros
        int* output = (int*)malloc(inputSize * numOutputs * sizeof(int));  // Allocate memory for the output

        // Process each input bit
        for (int i = 0; i < inputSize; i++) {
            // Shift the registers
            lastnum = registers[K - 2];
            for (int j = K - 2; j > 0; j--) {
                registers[j] = registers[j - 1];
            }
            registers[0] = input[i];

            // Calculate the outputs for the current input bit
            output[2 * i] = (registers[0] + lastnum) % 2;//5
            output[2 * i + 1] = (registers[0] + registers[1] + lastnum) % 2;//7
        }
        *outputSize = inputSize * numOutputs;  // Set the output size
        return output;
    }

