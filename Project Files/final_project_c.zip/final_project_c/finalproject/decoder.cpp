#include <iostream>
#include <vector>
#include <algorithm>



// Convert polynomials to binary
const std::string g1_bin = "10111001";  // Constraint length K=7
const std::string g2_bin = "10110011";  // Constraint length K=7

// Define Viterbi decoder
std::vector<int> viterbi_decoder(const std::vector<int>& received_sequence) {
    // Initialize trellis
    std::vector<std::vector<int>> trellis(received_sequence.size() / 2, std::vector<int>(8, 0));
    trellis[0][0] = 0;  // Start from state 0

    // Define branch metrics for each transition
    std::vector<std::vector<std::vector<int>>> branch_metrics(received_sequence.size() / 2, std::vector<std::vector<int>>(8, std::vector<int>(2, 0)));
    for (size_t i = 0; i < received_sequence.size(); i += 2) {
        for (int j = 0; j < 8; ++j) {
            // Transition to state j from state 0
            int next_state_0 = ((j << 1) & 0b111) | 0;
            int next_state_1 = ((j << 1) & 0b111) | 1;
            branch_metrics[i / 2][next_state_0][0] = received_sequence[i] ^ ((j >> 2) & 1);
            branch_metrics[i / 2][next_state_1][1] = received_sequence[i + 1] ^ ((j >> 2) & 1);
        }
    }

    // Compute path metrics
    for (size_t i = 1; i < received_sequence.size() / 2; ++i) {
        for (int j = 0; j < 8; ++j) {
            std::vector<int> path_metrics;
            for (int k = 0; k < 2; ++k) {
                int prev_state = ((j >> 1) & 0b111) | (k << 2);
                path_metrics.push_back(trellis[i - 1][prev_state] + branch_metrics[i][j][k]);
            }
            trellis[i][j] = *std::min_element(path_metrics.begin(), path_metrics.end());
        }
    }

    // Traceback to find the most likely path
    std::vector<int> decoded_sequence;
    int state = std::min_element(trellis.back().begin(), trellis.back().end()) - trellis.back().begin();
    for (int i = received_sequence.size() / 2 - 1; i >= 0; --i) {
        decoded_sequence.insert(decoded_sequence.begin(), state & 1);
        state = std::min_element(trellis[i].begin(), trellis[i].end()) - trellis[i].begin();
        state = ((state << 1) & 0b111) | ((decoded_sequence.front() << 2) & 0b1000);
    }

    return decoded_sequence;
}