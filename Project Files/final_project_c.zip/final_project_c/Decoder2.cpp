#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <math.h>
#define NUM_STATES 4
#define NUM_INPUTS 2


/**
 * Calculate the Hamming distance between two integers.
 *
 * @param a First integer
 * @param b Second integer
 * @return Hamming distance between a and b
 */

    int calculateHammingDistance(int a, int b) {
        int distance = 0;
        int xor_result = a ^ b; // XOR the two integers to find differing bits

        // Count the number of set bits (1s) in the XOR result
        while (xor_result > 0) {
            if (xor_result & 1) {
                distance++;
            }
            xor_result >>= 1; // Right shift to check the next bit
        }

        return distance;
    }


    // Viterbi Decoder Function for rate 1/2
    int* viterbiDecoder(const int* input, int inputSize) {
        // Transition matrix
        int transitionMatrix[NUM_STATES][NUM_INPUTS] = {
            {0, 2}, {0, 2}, {1, 3}, {1, 3}
        };
        int transitionoutMatrix[NUM_STATES][NUM_INPUTS] = {
          {0, 3}, {3, 0}, {1, 2}, {2, 1}
        };

        

        // Number of states
        int numStates = NUM_STATES;

        // Calculate the number of output bits
        int outputSize = inputSize /2;

        // Allocate memory for the decoded output array
        int* decodedOutput = (int*)malloc((outputSize+1) * sizeof(int));

        // Allocate memory for the Viterbi matrix
        int** viterbiMatrix = (int**)malloc(numStates * sizeof(int*));
        for (int i = 0; i < numStates; i++) {
            viterbiMatrix[i] = (int*)malloc((outputSize+1) * sizeof(int));
        }

        // Initialize the Viterbi matrix with infinity viterbi matrix saving the hamming distances(INT_MAX)
        for (int i = 0; i < numStates; i++) {
            for (int j = 0; j < outputSize+1; j++) {
                viterbiMatrix[i][j] = INT_MAX;
            }
        }

        // Initialize the path memory
        int** pathMemory = (int**)malloc(numStates * sizeof(int*));
        for (int i = 0; i < numStates; i++) {
            pathMemory[i] = (int*)malloc((outputSize+1) * sizeof(int));
        }
        // Initialize the out memory
        int** outMemory = (int**)malloc(numStates * sizeof(int*));
        for (int i = 0; i < numStates; i++) {
            outMemory[i] = (int*)malloc((outputSize+1) * sizeof(int));
        }


        // Initialize the first column of the Viterbi matrix
        for (int i = 0; i < numStates; i++) {
            viterbiMatrix[i][0] = 0;
            pathMemory[i][0] = 0;
            pathMemory[i][outputSize] = 0;
        }

        // Viterbi algorithm
        for (int i = 0; i < outputSize; i++) {
            for (int currentstate = 0; currentstate < numStates; currentstate++) {
                for (int k = 0; k < NUM_INPUTS; k++) {
                    int nextState = transitionMatrix[currentstate][k];
                    int outtry=  transitionoutMatrix[currentstate][k];
                    int inputBits = (input[2*(i)] << 1) | input[2*(i)+1]; // Combine two input bits into one value
                    int hammingDistance = calculateHammingDistance(inputBits, outtry);
                       
                    if (viterbiMatrix[nextState][i + 1] > (viterbiMatrix[currentstate][i] + hammingDistance)) {
                            viterbiMatrix[nextState][i + 1] = viterbiMatrix[currentstate][i] + hammingDistance;
                            pathMemory[nextState][i + 1] = currentstate;
                            outMemory[nextState][i + 1] = (nextState >> 1) & 1;
                        }
                    
                }
            }
        }
        // Backtrace to find the optimal path
        int currentState = 0;
        for (int i = outputSize; i >= 0; i--) {
            int nextState = pathMemory[currentState][i];
            decodedOutput[i] = outMemory[currentState][i+1];
            currentState = nextState;
        }
        decodedOutput[outputSize] = decodedOutput[0];
       

        // Adjust pointer to point to an array with 100 bits
        int* modified_pointer = decodedOutput + 1;
        // Free the memory allocated for the Viterbi matrix and path memory
        for (int i = 0; i < numStates; i++) {
            free(outMemory[i]);
            free(viterbiMatrix[i]);
            free(pathMemory[i]);
        }
        free(outMemory);
        free(viterbiMatrix);
        free(pathMemory);

        return modified_pointer;
    }



    // Viterbi Decoder Function for rate 1/3
    int* viterbiDecoder3(const int* input, int inputSize) {
        // Transition matrix
        int transitionMatrix[NUM_STATES][NUM_INPUTS] = {
            {0, 2}, {0, 2}, {1, 3}, {1, 3}
        };
        int transitionoutMatrix[NUM_STATES][NUM_INPUTS] = {
          {0, 7}, {7, 0}, {3, 4}, {4, 3}
        };



        // Number of states
        int numStates = NUM_STATES;

        // Calculate the number of output bits
        int outputSize = inputSize / 3;

        // Allocate memory for the decoded output array
        int* decodedOutput = (int*)malloc((outputSize + 1) * sizeof(int));

        // Allocate memory for the Viterbi matrix
        int** viterbiMatrix = (int**)malloc(numStates * sizeof(int*));
        for (int i = 0; i < numStates; i++) {
            viterbiMatrix[i] = (int*)malloc((outputSize + 1) * sizeof(int));
        }

        // Initialize the Viterbi matrix with infinity viterbi matrix saving the hamming distances(INT_MAX)
        for (int i = 0; i < numStates; i++) {
            for (int j = 0; j < outputSize + 1; j++) {
                viterbiMatrix[i][j] = INT_MAX;
            }
        }

        // Initialize the path memory
        int** pathMemory = (int**)malloc(numStates * sizeof(int*));
        for (int i = 0; i < numStates; i++) {
            pathMemory[i] = (int*)malloc((outputSize + 1) * sizeof(int));
        }
        // Initialize the out memory
        int** outMemory = (int**)malloc(numStates * sizeof(int*));
        for (int i = 0; i < numStates; i++) {
            outMemory[i] = (int*)malloc((outputSize + 1) * sizeof(int));
        }


        // Initialize the first column of the Viterbi matrix
        for (int i = 0; i < numStates; i++) {
            viterbiMatrix[i][0] = 0;
            pathMemory[i][0] = 0;
            pathMemory[i][outputSize] = 0;
        }

        // Viterbi algorithm
        for (int i = 0; i < outputSize; i++) {
            for (int currentstate = 0; currentstate < numStates; currentstate++) {
                for (int k = 0; k < NUM_INPUTS; k++) {
                    int nextState = transitionMatrix[currentstate][k];
                    int outtry = transitionoutMatrix[currentstate][k];
                    int inputBits = (input[3 * (i)] << 2) | (input[3 * (i)+1]<<1) | (input[3 * (i)+2]); // Combine three input bits into one value
                    int hammingDistance = calculateHammingDistance(inputBits, outtry);

                    if (viterbiMatrix[nextState][i + 1] > (viterbiMatrix[currentstate][i] + hammingDistance)) {
                        viterbiMatrix[nextState][i + 1] = viterbiMatrix[currentstate][i] + hammingDistance;
                        pathMemory[nextState][i + 1] = currentstate;
                        outMemory[nextState][i + 1] = (nextState >> 1) & 1;
                    }

                }
            }
        }
        // Backtrace to find the optimal path
        int currentState = 0;
        for (int i = outputSize; i >= 0; i--) {
            int nextState = pathMemory[currentState][i];
            decodedOutput[i] = outMemory[currentState][i + 1];
            currentState = nextState;
        }
        decodedOutput[outputSize] = decodedOutput[0];


        // Adjust pointer to point to an array with 100 bits
        int* modified_pointer = decodedOutput + 1;
        // Free the memory allocated for the Viterbi matrix and path memory
        for (int i = 0; i < numStates; i++) {
            free(outMemory[i]);
            free(viterbiMatrix[i]);
            free(pathMemory[i]);
        }
        free(outMemory);
        free(viterbiMatrix);
        free(pathMemory);

        return modified_pointer;
    }
    // Viterbi Decoder Function for rate 1/4
    int* viterbiDecoder4(const int* input, int inputSize) {
        // Transition matrix
        int transitionMatrix[NUM_STATES][NUM_INPUTS] = {
            {0, 2}, {0, 2}, {1, 3}, {1, 3}
        };
        int transitionoutMatrix[NUM_STATES][NUM_INPUTS] = {
          {0, 15}, {15, 0}, {7, 8}, {8, 7}
        };



        // Number of states
        int numStates = NUM_STATES;

        // Calculate the number of output bits
        int outputSize = inputSize / 4;

        // Allocate memory for the decoded output array
        int* decodedOutput = (int*)malloc((outputSize + 1) * sizeof(int));

        // Allocate memory for the Viterbi matrix
        int** viterbiMatrix = (int**)malloc(numStates * sizeof(int*));
        for (int i = 0; i < numStates; i++) {
            viterbiMatrix[i] = (int*)malloc((outputSize + 1) * sizeof(int));
        }

        // Initialize the Viterbi matrix with infinity viterbi matrix saving the hamming distances(INT_MAX)
        for (int i = 0; i < numStates; i++) {
            for (int j = 0; j < outputSize + 1; j++) {
                viterbiMatrix[i][j] = INT_MAX;
            }
        }

        // Initialize the path memory
        int** pathMemory = (int**)malloc(numStates * sizeof(int*));
        for (int i = 0; i < numStates; i++) {
            pathMemory[i] = (int*)malloc((outputSize + 1) * sizeof(int));
        }
        // Initialize the out memory
        int** outMemory = (int**)malloc(numStates * sizeof(int*));
        for (int i = 0; i < numStates; i++) {
            outMemory[i] = (int*)malloc((outputSize + 1) * sizeof(int));
        }


        // Initialize the first column of the Viterbi matrix
        for (int i = 0; i < numStates; i++) {
            viterbiMatrix[i][0] = 0;
            pathMemory[i][0] = 0;
            pathMemory[i][outputSize] = 0;
        }

        // Viterbi algorithm
        for (int i = 0; i < outputSize; i++) {
            for (int currentstate = 0; currentstate < numStates; currentstate++) {
                for (int k = 0; k < NUM_INPUTS; k++) {
                    int nextState = transitionMatrix[currentstate][k];
                    int outtry = transitionoutMatrix[currentstate][k];
                    int inputBits = (input[4 * (i)] << 3) | (input[4 * (i)+1] << 2) | (input[4 * (i)+2] << 1) | (input[4 * (i)+3]); // Combine four input bits into one value
                    int hammingDistance = calculateHammingDistance(inputBits, outtry);

                    if (viterbiMatrix[nextState][i + 1] > (viterbiMatrix[currentstate][i] + hammingDistance)) {
                        viterbiMatrix[nextState][i + 1] = viterbiMatrix[currentstate][i] + hammingDistance;
                        pathMemory[nextState][i + 1] = currentstate;
                        outMemory[nextState][i + 1] = (nextState >> 1) & 1;
                    }

                }
            }
        }
        // Backtrace to find the optimal path
        int currentState = 0;
        for (int i = outputSize; i >= 0; i--) {
            int nextState = pathMemory[currentState][i];
            decodedOutput[i] = outMemory[currentState][i + 1];
            currentState = nextState;
        }
        decodedOutput[outputSize] = decodedOutput[0];


        // Adjust pointer to point to an array with 100 bits
        int* modified_pointer = decodedOutput + 1;
        // Free the memory allocated for the Viterbi matrix and path memory
        for (int i = 0; i < numStates; i++) {
            free(outMemory[i]);
            free(viterbiMatrix[i]);
            free(pathMemory[i]);
        }
        free(outMemory);
        free(viterbiMatrix);
        free(pathMemory);

        return modified_pointer;
    }


  