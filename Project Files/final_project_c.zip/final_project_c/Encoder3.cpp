
#include <stdio.h>
#include <stdlib.h>

#define K 3

// Convolutional Encoder Function
int* convolutionalEncoder3(const int* input, int inputSize, int* outputSize) {
    int lastnum;
    int registers[K-1] = { 0 };  // Initialize registers to all zeros
    // Polynomial representation
    int polynomial1 = 5;
    int polynomial2 = 7;
    int polynomial3 = 7;


    // Calculate the number of output bits
    *outputSize = inputSize * 3;

    // Allocate memory for the output array
    int* output = (int*)malloc(*outputSize * sizeof(int));



    // Process each input bit
    for (int i = 0; i < inputSize; i++) {
        // Shift the registers
        lastnum = registers[K - 2];
        for (int j = K - 2; j > 0; j--) {
            registers[j] = registers[j - 1];
        }
        registers[0] = input[i];


        // Calculate the outputs for the current input bit
        output[3 * i] = (registers[0] + lastnum) % 2;//5
        output[3 * i + 1] = (registers[0] + registers[1] + lastnum) % 2;//7
        output[3 * i + 2] = (registers[0] + registers[1] + lastnum) % 2;//7

    }

    return output;
}

