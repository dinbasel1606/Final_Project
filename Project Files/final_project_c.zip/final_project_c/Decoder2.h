

#ifndef _Decoder_H_
#define _Decoder_H_


#define SIMULATION	1




 /**
  * Viterbi Decoder Function for the given input and input size.
  *
  * This function performs Viterbi decoding on an array of input bits.
  * It takes the input bit sequence and its size, performs decoding,
  * and returns the decoded output sequence.
  *
  * @param input Pointer to the array of input bits (0 or 1)
  * @param inputSize Number of input bits in the array
  * @return Pointer to the dynamically allocated array of decoded output bits
  */

int* viterbiDecoder(const int* input, int inputSize);
int* viterbiDecoder3(const int* input, int inputSize);
int* viterbiDecoder4(const int* input, int inputSize);



#endif 