
#include <stdlib.h>
#include <stdio.h>
#include <string.h>


/**
 * build the trellis - 2d unsigned array containing the source nodes for back tracking
 * @param decoder decoder
 * @param s input stream
 * @param lastState state to start the back track at last column (updated pointer)
 * @return the trellis
 */
unsigned **
build_trellis(Decoder *decoder, stream *s, unsigned *lastState) {
    unsigned k = decoder->k;


    // initialize trellis
    unsigned **trellis = (unsigned **) malloc((1u << (k - 1)) * sizeof(unsigned *)); // 2^(k-1) rows for all states
    for (int i = 0; i < (1u << (k - 1)); i++)
        trellis[i] = (unsigned *) malloc((size_stream(s) / decoder->polynomialsSize + 1) *
                                         sizeof(unsigned));  // no. of columns = packet_data_length of inputArray / no. of polynomials + 1

#if defined(DEBUG_VITERBI)
    // initialize weight trellis
    float **trellis_weights = malloc((1u << (k - 1)) * sizeof(float *)); // 2^(k-1) rows for all states
    for (int i = 0; i < (1u << (k - 1)); i++) {
        trellis_weights[i] = malloc((inputArraySize / decoder.polynomialsSize + 1) * sizeof(float));  // no. of columns = packet_data_length of inputArray / no. of polynomials + 1
    }
#endif

    // initialize working columns
    unsigned INIT_WEIGHT = VITERBI_UINT_MAX;                    // initial weight is infinity
    unsigned *columnWeightsNext = (unsigned *) malloc((1u << (k - 1)) * sizeof(unsigned));
    unsigned *columnWeightsCurrent = (unsigned *) malloc((1u << (k - 1)) * sizeof(unsigned));
    columnWeightsCurrent[0] = 0;                 // initialize state 0..0 weight to 0
    for (int i = 1; i < (1u << (k - 1)); i++)       // disable states other than 0..0
        columnWeightsCurrent[i] = INIT_WEIGHT;

    // update all the columns of the trellis
    unsigned stateMask = (1u << (k - 1)) - 2;  // 0..01..10 (leftmost 1 is at the leftmost bit of the state)
    unsigned sourceNode0, sourceNode1;
    unsigned input_bits, mask2;
    signed char bit;
    unsigned weight0, weight1; // weights of different branches
    for (unsigned col = 1;
         col < (size_stream(s) / decoder->polynomialsSize) + 1; col++) {  // iterate over columns (ignores first column)

        input_bits = 0;
        mask2 = 0;
        for (int i = 0; i < decoder->polynomialsSize; i++) {
            bit = read_next_stream(s); // 0,1,2
            mask2 <<= 1;
            input_bits <<= 1;
            if (bit == 2)
                mask2 |= 1;
            else
                input_bits |= bit;
        }
        mask2 = ~mask2;

        for (unsigned state = 0; state < (1u << (k - 1)); state++) {     // iterate over all states
            weight0 = weight1 = INIT_WEIGHT;
            sourceNode0 = (state << 1u) & stateMask;    // ignores leftmost bit of state and adds 0 as rightmost bit
            sourceNode1 = sourceNode0 + 1;              // ignores leftmost bit of state and adds 1 as rightmost bit

            if (columnWeightsCurrent[sourceNode0] != INIT_WEIGHT)
                weight0 = columnWeightsCurrent[sourceNode0] + count_set_bits((decoder->stateLookupTable[state << 1u] ^
                                                                              input_bits) &
                                                                             mask2); // calculate distance between parity bits and input array
            if (columnWeightsCurrent[sourceNode1] != INIT_WEIGHT)
                weight1 = columnWeightsCurrent[sourceNode1] +
                          count_set_bits((decoder->stateLookupTable[(state << 1u) + 1] ^
                                          input_bits) &
                                         mask2); // calculate distance between parity bits and input array

            // find min weight and save state to trellis
            columnWeightsNext[state] = (weight0 <= weight1 ? weight0 : weight1);
            if (weight0 == weight1) {
                trellis[state][col] = sourceNode0 | (stateMask + 2); // add equivalent path bit
            } else {
                trellis[state][col] = (weight0 <= weight1 ? sourceNode0 : sourceNode1);
            }

#if defined(DEBUG_VITERBI)
            trellis_weights[state][col] = columnWeightsNext[state];
#endif
        }

        //swap weight columns
        unsigned *tmp = columnWeightsNext;
        columnWeightsNext = columnWeightsCurrent;
        columnWeightsCurrent = tmp;
    }

    // find node with min weight at last column
    unsigned lastWeight = INIT_WEIGHT;
    for (unsigned state = 0; state < (1u << (k - 1)); state++) {    // iterate over all states
        if (columnWeightsCurrent[state] < lastWeight) { // find min state
            lastWeight = columnWeightsCurrent[state];
            *lastState = state;
        }
    }

    // free columns
    free(columnWeightsCurrent);
    free(columnWeightsNext);

#if defined(DEBUG_VITERBI)
    printf("\n\n");
    for (unsigned state = 0; state < (1u << (k - 1)); state++) {    // iterate over all states
        for (unsigned col = 0;
             col < inputArraySize / decoder.polynomialsSize + 1; col++) {   // iterate over all columns
            if (trellis_weights[state][col] == INIT_WEIGHT)
                printf("  INIT ");
            else
                printf("%+6.2f ", trellis_weights[state][col]);
        }
        printf("\n");
    }
    printf("\n");
    for (int i = 0; i < (1u << (decoder.k - 1)); i++)
        free(trellis_weights[i]);
    free(trellis_weights);
#endif

    return trellis;
}

/**
 * extract output message from the trellis (ignoring flushing bits)
 * @param k constraint packet_data_length
 * @param trellis
 * @param trellisColumnsSize no. of columns in the trellis
 * @param outputSize output message size
 * @param lastState lastState to begin the back track at last column of the trellis
 * @return output string
 */
char *back_track(unsigned k, unsigned **trellis, unsigned trellisColumnsSize, unsigned outputSize, unsigned lastState) {
    char *output = (char *) malloc((outputSize + 1) * sizeof(char));   // +1 for '\0'

    // iterate backwards on the trellis
    unsigned equivalentPath;
    unsigned bit;
    for (unsigned col = trellisColumnsSize - 1; col > 0; col--) {
        equivalentPath = (lastState & (1u << (k - 1))) >> (k - 1);
        lastState &= (1u << (k - 1)) - 1; // remove equivalent path bit
        bit = (lastState & (1u << (k - 2))) >> (k - 2);  // extract leftmost bit of the lastState
        if (col <= outputSize) {    // ignores flushing bits at the end
            if (equivalentPath) {
                output[col - 1] = '3';
            } else {
                output[col - 1] = (char) (bit + '0');
            }
        }
        lastState = trellis[lastState][col];    // fetch previous lastState
    }

    // check back track finish row
    if (lastState != 0) {
        printf("Back Track should finish at row 0. \n");
        exit(EXIT_FAIL);
    }

    // last char of the string
    output[outputSize] = '\0';

    return output;
}

/**
 * decode stream
 * @param decoder decoder
 * @param input input stream
 * @param crc_flag TRUE if input has crc, else FALSE
 * @return output stream on success, else NULL
 */
stream *decode_to_stream(Decoder *decoder, stream *input, unsigned char crc_flag) {
    init_stream(input); // go to start of stream

    // build trellis
    unsigned lastState;
    unsigned **trellis = build_trellis(decoder, input, &lastState);

#if defined(DEBUG_VITERBI)
    print_trellis(trellis, decoder.k, inputArraySize / decoder.polynomialsSize + 1);
    printf("Last state to start back track: %u\n\n", lastState);
#endif

    // perform back track on trellis
    unsigned outputSize = size_stream(input) / decoder->polynomialsSize - (decoder->k - 1); // k - 1 = zero padding
    char *output = back_track(decoder->k, trellis, size_stream(input) / decoder->polynomialsSize + 1, outputSize,
                              lastState);

    // free auxiliary resources
    for (int i = 0; i < (1u << (decoder->k - 1)); i++)
        free(trellis[i]);
    free(trellis);

    stream *output_stream = open_stream(output, StringType);

    // handle crc if exists
    if (crc_flag) { // last CRC_BIT_SIZE bits are crc bits
        stream *crc_stream = open_array(CRC_BIT_SIZE);

        unsigned last_bit_index = size_stream(output_stream); // the bit is '\0'
        for (unsigned i = last_bit_index - CRC_BIT_SIZE;
             i < last_bit_index; i++) { // copy last bits of output to crc stream (cast to unsigned char)
            signed char bit = read_stream(output_stream, i);
            write_next_stream(crc_stream, bit);
        }

        ((string *) output_stream->stream_ptr)->size -= CRC_BIT_SIZE; // remove CRC length from size
        ((string *) output_stream->stream_ptr)->data[size_stream(output_stream)] = '\0';
        // output_stream still has unused CRC_BIT_SIZE bits at the end

        // copy crc stream into data of crc struct
        for (int i = 0; i < sizeof(crc); i++) {
            ((unsigned char *) &(output_stream->c))[i] = ((array *) crc_stream->stream_ptr)->data[i];
        }

        output_stream->crc_flag = TRUE;

        close_stream(crc_stream);
    }

    return output_stream;
}

/**
 * initialize the decoder
 * @param k constraint length
 * @param polynomials polynomials array
 * @param polynomialsSize polynomials array size
 * @return EXIT_SUCC on success, else EXIT_FAIL
 */
signed int set_decoder(Decoder *decoder, unsigned  k, unsigned  *polynomials, unsigned  polynomialsSize) {
    decoder->k = k;
    decoder->polynomialsSize = polynomialsSize;
    memcpy(decoder->polynomials, polynomials, polynomialsSize * sizeof(unsigned ));
    build_state_lookup_table(decoder->stateLookupTable, k, polynomials, polynomialsSize);

    return EXIT_SUCC;
}

