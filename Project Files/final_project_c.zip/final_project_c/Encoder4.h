
#ifndef _Encoder4_H_
#define _Encoder4_H_




 /**
  * Convolutional Encoder
  *
  * This function performs convolutional encoding for rate 1/4 on a stream of input bits.
  * It takes an array of input bits, processes them through the encoder,
  * and produces an array of encoded output bits.
  *
  * @param input Pointer to the array of input bits (0 or 1)
  * @param inputSize Number of input bits in the array
  * @param outputSize Pointer to an integer where the output size will be stored
  * @return Pointer to the dynamically allocated array of encoded output bits
  */



int* convolutionalEncoder4(const int* input, int inputSize, int* outputSize);


#endif